<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Category</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <center>
    
    <h2>Add New Category</h2>

    <form action="add_category_logic.php" method="POST">
      <label>Category Name:</label><br>
      <input type="text" name="category_name" required><br><br>

      <label>News Type:</label><br>
      <input type="text" name="news_type"><br><br>

      <input type="submit" name="add_category" value="Add Category">
    </form>
  </center>
</body>
</html>

