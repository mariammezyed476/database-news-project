<?php
include "database.php";
function validateData($data) {
    $data = trim($data);
    $data = htmlspecialchars($data);
    return $data;
}
if($connectn->error == false ){

    if (isset($_POST["create_account"])){
        $name = validateData($_POST['name']);
        $email = validateData($_POST['email']);
        $password = password_hash(validateData($_POST["password"]),PASSWORD_BCRYPT);

        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
        $result =$connectn ->query($sql) ;
        if($result == true){
            header("Location: login.php?statusCode=201");
            // echo "Account created";
        } else {
            echo "Error";
        }
    }


}
?>
