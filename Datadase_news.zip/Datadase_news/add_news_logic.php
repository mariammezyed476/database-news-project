<?php
include "database.php";
session_start();

if (!isset($_SESSION["authUser"])) {
    header("Location: view_news.php");
    exit();
}

if (isset($_POST["add_news"])) {
    $title = $_POST["title"];
    $details = $_POST["details"];
    $category_name= $_POST["category_name"];
    $user_id = $_SESSION["authUser"]["id"];

    if (!is_dir("uploads")) {
        mkdir("uploads", 0777, true);
    }

    $image_name = "";
    if (!empty($_FILES["image"]["name"])) {
        $image_name = time() . "_" . $_FILES["image"]["name"];
        move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $image_name);
    }

    $sql = "INSERT INTO news (title, details, image, category_id, user_id) 
            VALUES ('$title', '$details', '$image_name', '$category_id', '$user_id')";

    if ($connectn->query($sql) === TRUE) {
        header("Location: view_news.php?added=true");
        exit();
    } else {
        echo "Error: " . $connectn->error;
    }
} else {
    echo "Form data not received.";
}
?>
