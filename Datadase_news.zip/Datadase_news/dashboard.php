<?php
session_start();
if (!isset($_SESSION["authUser"])) {
    header("Location: login.php");
    exit();
}
$name = $_SESSION["authUser"]["name"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<center>
    <h1>Hello <?php echo $name; ?> in Dashboard</h1>
    <a href="add_category.php">Add Category</a> | 
    <a href="view_categories.php">View Categories</a> | 
    <a href="add_news.php">Add News</a> | 
    <a href="view_news.php">View News</a>
</center>
</body>
</html>
