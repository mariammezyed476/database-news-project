<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add News</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <center>
    <h2>Add News</h2>

    <form action="add_news_logic.php" method="POST" enctype="multipart/form-data">
        <label>Title</label><br>
        <input type="text" name="title" required><br><br>

        <label>Details</label><br>
        <textarea name="details" required></textarea><br><br>

        <label>Category (News Type)</label><br>
        <input type="text" name="category_name"  required><br><br>

        <label>Image</label><br>
        <input type="file" name="image"><br><br>

        <input type="submit" name="add_news" value="Add News">

    </form>
    <br>
        <a href="dashboard.php">Back to Dashboard</a>
  </center>
</body>
</html>
