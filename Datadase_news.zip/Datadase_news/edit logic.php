<?php
include "database.php";

if (isset($_POST["update_news"])) {
    $id = $_POST["news_id"];
    $title = $_POST["new_title"];
    $details = $_POST["new_details"];
    $new_category = $_POST["new_category"];
    // جلب الصورة القديمة من قاعدة البيانات
    $result = $connectn->query("SELECT image FROM news WHERE id = $id");
    $oldImage = $result->fetch_assoc()["image"];

    // إذا تم رفع صورة جديدة
    if (!empty($_FILES["new_image"]["name"])) {
        $image_name = time() . "_" . $_FILES["new_image"]["name"];
        move_uploaded_file($_FILES["new_image"]["tmp_name"], "uploads/" . $image_name);
    } else {
        $image_name = $oldImage;
    }

    // تحديث البيانات في قاعدة البيانات
    $sql = "UPDATE news SET title='$title', details='$details', category_id='$new_category', image='$image_name' WHERE id=$id";

    if ($connectn->query($sql)) {
        // إعادة التوجيه إلى صفحة عرض الأخبار مع رسالة نجاح
        header("Location: view_news.php?updated=true");
        exit();
    } else {
        echo "Error: " . $connectn->error;
    }
}
?>
