<?php 
$connectn = new mysqli("localhost","root","",
"Database_news");

/*if($connectn->connect_error){
echo "Connection Failed";
}
else{
    echo "Connection Successful";
}



?>*/




