<?php
include "database.php";

$sql = "SELECT * FROM news WHERE is_deleted = 0 ORDER BY id DESC";
$result = $connectn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        
    <h1>Delete News</h1>
    
    <a href="dashboard.php">Dashboard</a><br>
    <a href="view_news.php">View News</a><br><br>
</body>
</html>
<form action="delete_news.php" method="post">
<table border="1" cellpadding="10" width="90%">
<tr>
    <th>Select</th>
    <th>Number</th>
    <th>Title</th>
    <th>Details</th>
    <th>Category</th>
    <th>Image</th>
    <th>User</th>
    <th>Date</th>
</tr>

<?php
$count = 1;
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><input type="checkbox" name="news_ids[]" value="<?php echo $row['id']; ?>"></td>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo nl2br(htmlspecialchars($row['details'])); ?></td>
            <td><?php echo htmlspecialchars($row['category_id']); ?></td>
            <td>
                <?php if (!empty($row['image'])) { ?>
                    <img src="uploads/<?php echo $row['image']; ?>" width="80">
                <?php } else { echo "No image"; } ?>
            </td>
            <td><?php echo htmlspecialchars($row['user_id']); ?></td>
            <td><?php echo $row['created_at']; ?></td>
        </tr>
    <?php $count++;
    }
if ($count === 1) {
    echo "No news found</td></tr>";
}}
?>
</table>
<br>
<input type="submit" value="Delete selected news" name="delete_news" >
</form>
</center