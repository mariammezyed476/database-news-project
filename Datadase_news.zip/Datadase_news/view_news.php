<?php
include "database.php";
// هذا هو الاستعلام الذي يجب استخدامه في صفحة العرض
$result = $connectn->query("SELECT * FROM news WHERE is_deleted = 0 ORDER BY id DESC");

?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>Show News</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<center>
<h2>Show All News</h2>
<a href="dashboard.php">Dashboard</a><br>
<a href="add_news.php">add new news</a><br>
<?php
if(isset($_GET['added']) && $_GET['added'] == 'true') {
    echo " News added successfully ";}
    
if (isset($_GET['updated']) && $_GET['updated'] == 'true') {
    echo " News Edit successfully";
}
if (isset($_GET['deleted']) && $_GET['deleted'] == 'true') {
    echo " News Deleted successfully";
}
?>


<?php 
if ($result && $result->num_rows > 0) { 
?>
    <table border="1" cellpadding="10" width="90%">
        <tr>
            <th>Number</th>
            <th>Title</th>
            <th>Details</th>
            <th>Category</th>
            <th>Image</th>
            <th>User</th>
            <th>Date</th>
            <th>Transactions</th>
        </tr>
        <?php 
        $count = 1;
        while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $count++; ?></td>
                <td><?php echo htmlspecialchars($row["title"]); ?></td>
                <td><?php echo nl2br(htmlspecialchars($row["details"])); ?></td>
                <td><?php echo htmlspecialchars($row["category_id"]); ?></td>
                <td>
                    <?php if (!empty($row["image"])) { ?>
                        <img src="uploads/<?php echo $row["image"]; ?>" width="80">
                    <?php } else { echo "no imge"; } ?>
                </td>
                <td><?php echo htmlspecialchars($row["user_id"]); ?></td>
                <td><?php echo $row["created_at"]; ?></td>
                <td>
               <a href="delete_news.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this news?');">
                                                Delete
                                                </a>

                <a href="edit_news.php?id=<?php echo $row['id']; ?>">Edit</a> 

               


                </td>
            </tr>
        <?php } ?>
    </table>
<?php 
} else { 
    echo "no news found";
} 
?>

<br>

</center>
</body>
</html>
