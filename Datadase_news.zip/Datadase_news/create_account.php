<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Register</title>
</head>
<body>
<center>
    <h1>Welcome to the news site</h1><br> 
    <h2>Create Account</h2>
    <form action="create_account_logic.php" method="post">
        <input type="text" name="name" placeholder="Name" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="submit" name="create_account" value="create account">
    </form>
</center>
</body>
</html>
