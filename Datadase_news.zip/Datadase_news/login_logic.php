<?php
session_start();
include "database.php";
if($connectn->error == false ){
if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $connectn->query($sql);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        if (password_verify($password, $data["password"])) {
            //echo "Login successful";
            $_SESSION["authUser"] = $data;
            header("Location: dashboard.php");
        } else {
            echo "Login failed";
        }
    } else {
        echo "Login failed ";
    }
}}



?>

