<?php
include "database.php";

$sql = "SELECT * FROM categories ORDER BY id DESC";
$result = $connectn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <title>View Categories</title>
</head>
<body>
<center>
    <h2>All Categories</h2>

    <?php
   
    if (isset($_GET['added']) && $_GET['added'] == 'true') {
        echo " Category added successfully!";
    }
    ?>

    <table border="1" cellpadding="8">
        <tr>
            <th>ID</th>
            <th>Category Name</th>
            <th>News Type</th>
        </tr>

        <?php
        if ($result->num_rows != 0) {
            while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo $row["category_name"]; ?></td>
                    <td><?php echo $row["news_type"]; ?></td>
                </tr>
            <?php }
        } else {
            echo "<tr><td colspan='3'>No categories found</td></tr>";
        }
        ?>
    </table>
</center>
</body>
</html>
