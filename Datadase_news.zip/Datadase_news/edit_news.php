<?php
$id = $_GET['id'] ?? null;
$title = $_GET['title'] ?? '';
$details = $_GET['details'] ?? '';
$image = $_GET['image'] ?? '';
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <link rel="stylesheet" href="style.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editing the news</title>
</head>
<body>
<center><h1>News Edit Page</h1></center>

<center>
<form action="edit logic.php" method="post" enctype="multipart/form-data">

<input type="hidden" name="news_id" value="<?php echo $_GET['id']; ?>">

<label>Title</label><br>
<input type="text" name="new_title" placeholder="News title" value="<?php echo htmlspecialchars($title); ?>">
<br><br>
<lable> Category </lable><br>
<input type="text" name="new_category" placeholder="News Category" value="<?php echo htmlspecialchars($new_category ?? ''); ?>">
<br>
<label>Details:</label><br>
<textarea name="new_details"><?php echo htmlspecialchars($details); ?></textarea> <br><br>


<label>Change Image:</label><br>
<input type="file" name="new_image">
<img src="uploads/<?php echo htmlspecialchars($image); ?>" width="100"><br><br>
<br><br>

<input type="submit" value="Update News" name="update_news">
</Form>
</Center>
</Body>
</html>