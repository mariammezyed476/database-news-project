<?php
include "database.php";

if (isset($_POST["add_category"])) {
    $category_name = $_POST["category_name"];
    $news_type = $_POST["news_type"];
    

    $sql = "INSERT INTO categories (category_name, news_type) VALUES ('$category_name', '$news_type')";

    if ($connectn->query($sql) === TRUE) {
        header("Location: view_categories.php?added=true");
        exit();
    } else {
        echo "Error: " . $connectn->error;
    }
}
?>
