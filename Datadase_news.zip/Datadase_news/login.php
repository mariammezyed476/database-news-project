<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
</head>
<body>
<center>
    <h1> Hello in Login Page</h1>
    <?php
     if(isset($_GET["statusCode"])){
                   if($_GET["statusCode"]=="201"){
                     echo "<b> Account Created ! </b>";
            }
        }
         ?>
    <form action="login_logic.php" method="post">
        <lable> email </label>
        <input type="email" name="email" placeholder="email">
        <br>
        <lable> password </label>
        <input type="password" name="password" placeholder="password">
        <br>
        <input type="submit" name = "login" value="login">
    </form>
    
</center>
</body>
</html>
