<?php
include "database.php";

if (isset($_GET["id"])) {
    $id = $_GET["id"]; 
    $stmt->bind_param("i", $id); 
    $sql = "UPDATE news SET is_deleted = 1 WHERE id = CAST('$id' AS SIGNED INTEGER)";

    if ($connectn->query($sql) === TRUE) {
        header("Location: view_news.php?deleted=true");
        exit();
    } else {
        echo "error " . $connectn->error;
    }

} else {
    echo "Not found";
}
?>